// Export Ghidra decompiler output for every discovered function.
// @category Export

import java.io.File;
import java.io.PrintWriter;

import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionIterator;

public class ExportDecompiled extends GhidraScript {
    @Override
    public void run() throws Exception {
        String[] args = getScriptArgs();
        if (args.length != 1) {
            throw new IllegalArgumentException("Usage: ExportDecompiled.java <output-file>");
        }

        DecompInterface decompiler = new DecompInterface();
        decompiler.openProgram(currentProgram);

        int exported = 0;
        try (PrintWriter output = new PrintWriter(new File(args[0]))) {
            FunctionIterator functions =
                currentProgram.getFunctionManager().getFunctions(true);

            while (functions.hasNext() && !monitor.isCancelled()) {
                Function function = functions.next();
                DecompileResults result =
                    decompiler.decompileFunction(function, 60, monitor);

                output.printf(
                    "\n/* %s at %s */\n",
                    function.getName(),
                    function.getEntryPoint()
                );

                if (result.decompileCompleted()) {
                    output.println(
                        result.getDecompiledFunction().getC()
                    );
                    exported++;
                } else {
                    output.printf(
                        "/* Decompilation failed: %s */\n",
                        result.getErrorMessage()
                    );
                }
            }
        } finally {
            decompiler.dispose();
        }

        println("Exported " + exported + " functions to " + args[0]);
    }
}
