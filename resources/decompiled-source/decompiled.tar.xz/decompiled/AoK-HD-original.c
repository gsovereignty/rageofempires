
/* FUN_00401000 at 00401000 */

undefined4 FUN_00401000(void)

{
  MessageBoxW((HWND)0x0,L"This is not the .exe you are looking for.",L"Dummy File",0);
  return 1;
}



/* ___tmainCRTStartup at 00401076 */

/* WARNING: Function: __SEH_prolog4 replaced with injection: SEH_prolog4 */
/* WARNING: Function: __SEH_epilog4 replaced with injection: EH_epilog3 */
/* Library Function - Single Match
    ___tmainCRTStartup
   
   Library: Visual Studio 2010 Release */

int ___tmainCRTStartup(void)

{
  ushort uVar1;
  LONG LVar2;
  int iVar3;
  BOOL BVar4;
  _STARTUPINFOW local_70;
  ushort *local_28;
  int local_24;
  uint local_20;
  undefined4 uStack_c;
  undefined *local_8;
  
  local_8 = &DAT_004021a8;
  uStack_c = 0x401082;
  local_20 = 0;
  GetStartupInfoW(&local_70);
  if (DAT_00403518 == 0) {
    HeapSetInformation((HANDLE)0x0,HeapEnableTerminationOnCorruption,(PVOID)0x0,0);
  }
  local_8 = (undefined *)0x0;
  iVar3 = *(int *)((int)Self + 4);
  local_24 = 0;
  do {
    LVar2 = InterlockedCompareExchange((LONG *)&DAT_0040350c,iVar3,0);
    if (LVar2 == 0) {
LAB_004010e1:
      if (DAT_00403508 == 1) {
        _amsg_exit(0x1f);
      }
      else if (DAT_00403508 == 0) {
        DAT_00403508 = 1;
        iVar3 = initterm_e(&DAT_004020bc,&DAT_004020c8);
        if (iVar3 != 0) {
          return 0xff;
        }
      }
      else {
        DAT_00403034 = 1;
      }
      if (DAT_00403508 == 1) {
        initterm(&DAT_004020b0,&DAT_004020b8);
        DAT_00403508 = 2;
      }
      if (local_24 == 0) {
        InterlockedExchange((LONG *)&DAT_0040350c,0);
      }
      if ((DAT_0040351c != (code *)0x0) &&
         (BVar4 = __IsNonwritableInCurrentImage((PBYTE)&DAT_0040351c), BVar4 != 0)) {
        (*DAT_0040351c)(0,2,0);
      }
      local_28 = *(ushort **)_wcmdln_exref;
      while ((uVar1 = *local_28, 0x20 < uVar1 || ((uVar1 != 0 && (local_20 != 0))))) {
        if (uVar1 == 0x22) {
          local_20 = (uint)(local_20 == 0);
        }
        local_28 = local_28 + 1;
      }
      for (; (*local_28 != 0 && (*local_28 < 0x21)); local_28 = local_28 + 1) {
      }
      DAT_00403030 = FUN_00401000();
      if (DAT_00403024 != 0) {
        if (DAT_00403034 == 0) {
          _cexit();
        }
        return DAT_00403030;
      }
                    /* WARNING: Subroutine does not return */
      exit(DAT_00403030);
    }
    if (LVar2 == iVar3) {
      local_24 = 1;
      goto LAB_004010e1;
    }
    Sleep(1000);
  } while( true );
}



/* entry at 00401301 */

void entry(void)

{
  ___security_init_cookie();
  ___tmainCRTStartup();
  return;
}



/* ___report_gsfailure at 0040130b */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* Library Function - Single Match
    ___report_gsfailure
   
   Libraries: Visual Studio 2005 Release, Visual Studio 2008 Release, Visual Studio 2010 Release */

void __cdecl ___report_gsfailure(void)

{
  undefined4 in_EAX;
  HANDLE hProcess;
  undefined4 in_ECX;
  undefined4 in_EDX;
  undefined4 unaff_EBX;
  undefined4 unaff_EBP;
  undefined4 unaff_ESI;
  undefined4 unaff_EDI;
  undefined2 in_ES;
  undefined2 in_CS;
  undefined2 in_SS;
  undefined2 in_DS;
  undefined2 in_FS;
  undefined2 in_GS;
  byte in_AF;
  byte in_TF;
  byte in_IF;
  byte in_NT;
  byte in_AC;
  byte in_VIF;
  byte in_VIP;
  byte in_ID;
  undefined4 unaff_retaddr;
  UINT uExitCode;
  undefined4 local_32c;
  undefined4 local_328;
  
  _DAT_00403150 =
       (uint)(in_NT & 1) * 0x4000 | (uint)SBORROW4((int)&stack0xfffffffc,0x328) * 0x800 |
       (uint)(in_IF & 1) * 0x200 | (uint)(in_TF & 1) * 0x100 | (uint)((int)&local_32c < 0) * 0x80 |
       (uint)(&stack0x00000000 == (undefined1 *)0x32c) * 0x40 | (uint)(in_AF & 1) * 0x10 |
       (uint)((POPCOUNT((uint)&local_32c & 0xff) & 1U) == 0) * 4 |
       (uint)(&stack0xfffffffc < (undefined1 *)0x328) | (uint)(in_ID & 1) * 0x200000 |
       (uint)(in_VIP & 1) * 0x100000 | (uint)(in_VIF & 1) * 0x80000 | (uint)(in_AC & 1) * 0x40000;
  _DAT_00403154 = &stack0x00000004;
  _DAT_00403090 = 0x10001;
  _DAT_00403038 = 0xc0000409;
  _DAT_0040303c = 1;
  local_32c = DAT_00403000;
  local_328 = DAT_00403004;
  _DAT_00403044 = unaff_retaddr;
  _DAT_0040311c = in_GS;
  _DAT_00403120 = in_FS;
  _DAT_00403124 = in_ES;
  _DAT_00403128 = in_DS;
  _DAT_0040312c = unaff_EDI;
  _DAT_00403130 = unaff_ESI;
  _DAT_00403134 = unaff_EBX;
  _DAT_00403138 = in_EDX;
  _DAT_0040313c = in_ECX;
  _DAT_00403140 = in_EAX;
  _DAT_00403144 = unaff_EBP;
  DAT_00403148 = unaff_retaddr;
  _DAT_0040314c = in_CS;
  _DAT_00403158 = in_SS;
  DAT_00403088 = IsDebuggerPresent();
  _crt_debugger_hook(1);
  SetUnhandledExceptionFilter((LPTOP_LEVEL_EXCEPTION_FILTER)0x0);
  UnhandledExceptionFilter((_EXCEPTION_POINTERS *)&PTR_DAT_004020d0);
  if (DAT_00403088 == 0) {
    _crt_debugger_hook(1);
  }
  uExitCode = 0xc0000409;
  hProcess = GetCurrentProcess();
  TerminateProcess(hProcess,uExitCode);
  return;
}



/* __CxxUnhandledExceptionFilter at 00401411 */

/* Library Function - Single Match
    long __stdcall __CxxUnhandledExceptionFilter(struct _EXCEPTION_POINTERS *)
   
   Libraries: Visual Studio 2008 Release, Visual Studio 2010 Release */

long __CxxUnhandledExceptionFilter(_EXCEPTION_POINTERS *param_1)

{
  PEXCEPTION_RECORD pEVar1;
  ULONG_PTR UVar2;
  
  pEVar1 = param_1->ExceptionRecord;
  if (((pEVar1->ExceptionCode == 0xe06d7363) && (pEVar1->NumberParameters == 3)) &&
     ((UVar2 = pEVar1->ExceptionInformation[0], UVar2 == 0x19930520 ||
      (((UVar2 == 0x19930521 || (UVar2 == 0x19930522)) || (UVar2 == 0x1994000)))))) {
                    /* WARNING: Subroutine does not return */
    terminate();
  }
  return 0;
}



/* _amsg_exit at 00401462 */

void __cdecl _amsg_exit(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00401462. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _amsg_exit(param_1);
  return;
}



/* __onexit at 00401468 */

/* WARNING: Function: __SEH_prolog4 replaced with injection: SEH_prolog4 */
/* WARNING: Function: __SEH_epilog4 replaced with injection: EH_epilog3 */
/* Library Function - Single Match
    __onexit
   
   Library: Visual Studio 2010 Release */

_onexit_t __cdecl __onexit(_onexit_t param_1)

{
  _onexit_t p_Var1;
  PVOID pvVar2;
  PVOID *ppvVar3;
  PVOID *ppvVar4;
  PVOID local_24;
  PVOID local_20 [5];
  undefined4 uStack_c;
  undefined *local_8;
  
  local_8 = &DAT_004021c8;
  uStack_c = 0x401474;
  local_20[0] = DecodePointer(DAT_00403514);
  if (local_20[0] == (PVOID)0xffffffff) {
    p_Var1 = _onexit(param_1);
  }
  else {
    _lock(8);
    local_8 = (undefined *)0x0;
    local_20[0] = DecodePointer(DAT_00403514);
    local_24 = DecodePointer(DAT_00403510);
    ppvVar4 = &local_24;
    ppvVar3 = local_20;
    pvVar2 = EncodePointer(param_1);
    p_Var1 = (_onexit_t)__dllonexit(pvVar2,ppvVar3,ppvVar4);
    DAT_00403514 = EncodePointer(local_20[0]);
    DAT_00403510 = EncodePointer(local_24);
    local_8 = (undefined *)0xfffffffe;
    FUN_00401500();
  }
  return p_Var1;
}



/* FUN_00401500 at 00401500 */

void FUN_00401500(void)

{
  _unlock(8);
  return;
}



/* _atexit at 00401509 */

/* Library Function - Single Match
    _atexit
   
   Library: Visual Studio 2010 Release */

int __cdecl _atexit(_func_4879 *param_1)

{
  _onexit_t p_Var1;
  
  p_Var1 = __onexit((_onexit_t)param_1);
  return (p_Var1 != (_onexit_t)0x0) - 1;
}



/* FUN_00401520 at 00401520 */

/* WARNING: Removing unreachable block (ram,0x00401534) */
/* WARNING: Removing unreachable block (ram,0x0040153a) */
/* WARNING: Removing unreachable block (ram,0x0040153c) */

void FUN_00401520(void)

{
  return;
}



/* _XcptFilter at 0040156c */

int __cdecl _XcptFilter(ulong _ExceptionNum,_EXCEPTION_POINTERS *_ExceptionPtr)

{
  int iVar1;
  
                    /* WARNING: Could not recover jumptable at 0x0040156c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  iVar1 = _XcptFilter(_ExceptionNum,_ExceptionPtr);
  return iVar1;
}



/* __ValidateImageBase at 00401580 */

/* Library Function - Single Match
    __ValidateImageBase
   
   Libraries: Visual Studio 2008 Release, Visual Studio 2010 Release */

BOOL __cdecl __ValidateImageBase(PBYTE pImageBase)

{
  if ((*(short *)pImageBase == 0x5a4d) &&
     (*(int *)(pImageBase + *(int *)(pImageBase + 0x3c)) == 0x4550)) {
    return (uint)((short)*(int *)((int)(pImageBase + *(int *)(pImageBase + 0x3c)) + 0x18) == 0x10b);
  }
  return 0;
}



/* __FindPESection at 004015c0 */

/* Library Function - Single Match
    __FindPESection
   
   Library: Visual Studio 2010 Release */

PIMAGE_SECTION_HEADER __cdecl __FindPESection(PBYTE pImageBase,DWORD_PTR rva)

{
  int iVar1;
  PIMAGE_SECTION_HEADER p_Var2;
  uint uVar3;
  
  iVar1 = *(int *)(pImageBase + 0x3c);
  uVar3 = 0;
  p_Var2 = (PIMAGE_SECTION_HEADER)
           (pImageBase + *(ushort *)(pImageBase + iVar1 + 0x14) + 0x18 + iVar1);
  if (*(ushort *)(pImageBase + iVar1 + 6) != 0) {
    do {
      if ((p_Var2->VirtualAddress <= rva) &&
         (rva < (p_Var2->Misc).PhysicalAddress + p_Var2->VirtualAddress)) {
        return p_Var2;
      }
      uVar3 = uVar3 + 1;
      p_Var2 = p_Var2 + 1;
    } while (uVar3 < *(ushort *)(pImageBase + iVar1 + 6));
  }
  return (PIMAGE_SECTION_HEADER)0x0;
}



/* __IsNonwritableInCurrentImage at 00401610 */

/* Library Function - Single Match
    __IsNonwritableInCurrentImage
   
   Library: Visual Studio 2010 Release */

BOOL __cdecl __IsNonwritableInCurrentImage(PBYTE pTarget)

{
  BOOL BVar1;
  PIMAGE_SECTION_HEADER p_Var2;
  void *local_14;
  code *pcStack_10;
  uint local_c;
  undefined4 local_8;
  
  pcStack_10 = FUN_00401739;
  local_14 = ExceptionList;
  local_c = DAT_00403000 ^ 0x4021e8;
  ExceptionList = &local_14;
  local_8 = 0;
  BVar1 = __ValidateImageBase((PBYTE)&IMAGE_DOS_HEADER_00400000);
  if (BVar1 != 0) {
    p_Var2 = __FindPESection((PBYTE)&IMAGE_DOS_HEADER_00400000,(DWORD_PTR)(pTarget + -0x400000));
    if (p_Var2 != (PIMAGE_SECTION_HEADER)0x0) {
      ExceptionList = local_14;
      return ~(p_Var2->Characteristics >> 0x1f) & 1;
    }
  }
  ExceptionList = local_14;
  return 0;
}



/* initterm at 004016cc */

void __cdecl initterm(void)

{
                    /* WARNING: Could not recover jumptable at 0x004016cc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  initterm();
  return;
}



/* initterm_e at 004016d2 */

void __cdecl initterm_e(void)

{
                    /* WARNING: Could not recover jumptable at 0x004016d2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  initterm_e();
  return;
}



/* __SEH_prolog4 at 004016e0 */

/* WARNING: This is an inlined function */
/* WARNING: Unable to track spacebase fully for stack */
/* WARNING: Variable defined which should be unmapped: param_2 */
/* Library Function - Single Match
    __SEH_prolog4
   
   Library: Visual Studio */

void __cdecl __SEH_prolog4(undefined4 param_1,int param_2)

{
  int iVar1;
  undefined4 unaff_EBX;
  undefined4 unaff_ESI;
  undefined4 unaff_EDI;
  undefined4 unaff_retaddr;
  uint auStack_1c [5];
  undefined1 local_8 [8];
  
  iVar1 = -param_2;
  *(undefined4 *)((int)auStack_1c + iVar1 + 0x10) = unaff_EBX;
  *(undefined4 *)((int)auStack_1c + iVar1 + 0xc) = unaff_ESI;
  *(undefined4 *)((int)auStack_1c + iVar1 + 8) = unaff_EDI;
  *(uint *)((int)auStack_1c + iVar1 + 4) = DAT_00403000 ^ (uint)&param_2;
  *(undefined4 *)((int)auStack_1c + iVar1) = unaff_retaddr;
  ExceptionList = local_8;
  return;
}



/* __SEH_epilog4 at 00401725 */

/* WARNING: This is an inlined function */
/* Library Function - Single Match
    __SEH_epilog4
   
   Library: Visual Studio */

void __SEH_epilog4(void)

{
  undefined4 *unaff_EBP;
  undefined4 unaff_retaddr;
  
  ExceptionList = (void *)unaff_EBP[-4];
  *unaff_EBP = unaff_retaddr;
  return;
}



/* FUN_00401739 at 00401739 */

void __cdecl
FUN_00401739(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  except_handler4_common(&DAT_00403000,&LAB_0040101c,param_1,param_2,param_3,param_4);
  return;
}



/* FUN_0040175e at 0040175e */

void FUN_0040175e(void)

{
  errno_t eVar1;
  
  eVar1 = _controlfp_s((uint *)0x0,0x10000,0x30000);
  if (eVar1 != 0) {
                    /* WARNING: Subroutine does not return */
    _invoke_watson((wchar_t *)0x0,(wchar_t *)0x0,(wchar_t *)0x0,0,0);
  }
  return;
}



/* FUN_00401786 at 00401786 */

undefined4 FUN_00401786(void)

{
  return 0;
}



/* ___security_init_cookie at 00401789 */

/* Library Function - Single Match
    ___security_init_cookie
   
   Library: Visual Studio 2010 Release */

void __cdecl ___security_init_cookie(void)

{
  DWORD DVar1;
  DWORD DVar2;
  DWORD DVar3;
  uint uVar4;
  LARGE_INTEGER local_14;
  _FILETIME local_c;
  
  local_c.dwLowDateTime = 0;
  local_c.dwHighDateTime = 0;
  if ((DAT_00403000 == 0xbb40e64e) || ((DAT_00403000 & 0xffff0000) == 0)) {
    GetSystemTimeAsFileTime(&local_c);
    uVar4 = local_c.dwHighDateTime ^ local_c.dwLowDateTime;
    DVar1 = GetCurrentProcessId();
    DVar2 = GetCurrentThreadId();
    DVar3 = GetTickCount();
    QueryPerformanceCounter(&local_14);
    DAT_00403000 = uVar4 ^ DVar1 ^ DVar2 ^ DVar3 ^ local_14.s.HighPart ^ local_14.s.LowPart;
    if (DAT_00403000 == 0xbb40e64e) {
      DAT_00403000 = 0xbb40e64f;
    }
    else if ((DAT_00403000 & 0xffff0000) == 0) {
      DAT_00403000 = DAT_00403000 | (DAT_00403000 | 0x4711) << 0x10;
    }
  }
  DAT_00403004 = ~DAT_00403000;
  return;
}



/* _crt_debugger_hook at 00401824 */

void __cdecl _crt_debugger_hook(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00401824. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _crt_debugger_hook(param_1);
  return;
}



/* terminate at 0040182a */

void __cdecl terminate(void)

{
                    /* WARNING: Could not recover jumptable at 0x0040182a. Too many branches */
                    /* WARNING: Subroutine does not return */
                    /* WARNING: Treating indirect jump as call */
  terminate();
  return;
}



/* _unlock at 00401830 */

void __cdecl _unlock(int _File)

{
                    /* WARNING: Could not recover jumptable at 0x00401830. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _unlock(_File);
  return;
}



/* __dllonexit at 00401836 */

void __dllonexit(void)

{
                    /* WARNING: Could not recover jumptable at 0x00401836. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  __dllonexit();
  return;
}



/* _lock at 0040183c */

void __cdecl _lock(int _File)

{
                    /* WARNING: Could not recover jumptable at 0x0040183c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _lock(_File);
  return;
}



/* except_handler4_common at 00401842 */

void __cdecl except_handler4_common(void)

{
                    /* WARNING: Could not recover jumptable at 0x00401842. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  except_handler4_common();
  return;
}



/* _invoke_watson at 00401848 */

void __cdecl
_invoke_watson(wchar_t *param_1,wchar_t *param_2,wchar_t *param_3,uint param_4,uintptr_t param_5)

{
                    /* WARNING: Could not recover jumptable at 0x00401848. Too many branches */
                    /* WARNING: Subroutine does not return */
                    /* WARNING: Treating indirect jump as call */
  _invoke_watson(param_1,param_2,param_3,param_4,param_5);
  return;
}



/* _controlfp_s at 0040184e */

errno_t __cdecl _controlfp_s(uint *_CurrentState,uint _NewValue,uint _Mask)

{
  errno_t eVar1;
  
                    /* WARNING: Could not recover jumptable at 0x0040184e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  eVar1 = _controlfp_s(_CurrentState,_NewValue,_Mask);
  return eVar1;
}


