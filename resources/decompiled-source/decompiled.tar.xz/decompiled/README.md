# Age of Empires II HD software-archaeology corpus

This directory contains reproducible static-analysis artifacts recovered from
the supplied 2013 Windows release. It is intended for software-engineering
history research, not as reconstructed or buildable source code.

## Corpus

| Artifact | Input | Functions | Output size |
|---|---|---:|---:|
| `AoK-HD-patched.c` | `Crack/AoK HD.exe` | 10,258 | 17,469,718 bytes |
| `AoK-HD-original.c` | installer `AoK HD.exe` | 30 | 16,039 bytes |
| `steam-api-patched.c` | `Crack/steam_api.dll` | 1,964 | 1,471,858 bytes |
| `steam-api-original.c` | installer `steam_api.dll` | 444 | 472,900 bytes |

Ghidra 12.1.2 produced all four C-like listings using its default x86 Windows
analysis. `ExportDecompiled.java` exports every function discovered by Ghidra.
`function-index.tsv` provides a compact address-to-generated-name index.
`pe-metadata-and-imports.txt` preserves headers, sections, imports, and exports.
`AoK-HD-patched.strings.txt` provides searchable printable-string evidence.

The installer executable is Inno Setup 5.4.2. Its `AoK HD.exe` is a 55 KiB
dummy whose only application behavior is a message box saying:

> This is not the .exe you are looking for.

The supplied `Crack/AoK HD.exe` is 4.2 MiB and contains the substantial game
implementation. Hashes prove it is not the installer version. Treat the labels
“original” and “patched” as provenance labels for this corpus, not claims about
Microsoft's complete historical build lineage.

## What the listings preserve

- Machine-level control flow recovered as structured C-like pseudocode.
- Calls to imported Windows, Direct3D 9, DirectSound, Steam, and zlib APIs.
- Constants, embedded addresses, strings, and inferred calling conventions.
- Some compiler/runtime functions recognized by Ghidra signatures.

## What was lost

- Original identifiers, comments, files, build scripts, macros, and formatting.
- Reliable high-level classes, templates, ownership, and many data types.
- Exact source expressions: compiler optimizations merge or remove operations.
- Functions unreachable through static analysis or hidden by indirect dispatch.
- A buildable program. Generated listings are evidence, not source restoration.

Addresses and `FUN_...` names are stable only for these exact binary hashes.
Decompiler output can also contain false types, false function boundaries, and
misstructured loops. Thesis claims should be corroborated with disassembly,
imports, strings, runtime observation, or multiple decompilers.

## Research workflow

1. Establish provenance from `MANIFEST.md` and retain immutable binary hashes.
2. Use `function-index.tsv` to select bounded subsystems or address ranges.
3. Open `ghidra-project` for cross-references, call graphs, and type refinement.
4. Rename functions only after recording evidence and confidence.
5. Keep observations separate from interpretation in research notes.
6. Compare measurable traits: function size, call fan-out, API dependencies,
   global-state access, error handling, allocation, and subsystem boundaries.
7. Validate historical-development claims against contemporary source,
   documentation, interviews, or later legally obtained builds.

Strong thesis framing compares artifacts across versions or eras. One binary
can support a case study, but cannot alone establish how software engineering
generally evolved.

## Reproduction

Requirements:

- `innoextract` 1.9
- Ghidra 12.1.2
- OpenJDK 21

Run:

```sh
./reproduce.sh
```

Script extracts only target binaries and regenerates all pseudocode and index
files. Ghidra analysis databases remain in `ghidra-project`.

## Ethics and handling

Do not redistribute copyrighted binaries or crack components. For publication,
share hashes, methodology, measurements, and small excerpts where legally
appropriate. Prefer a legally obtained matching release for final thesis work.
Static analysis does not prove binaries safe; analyze unknown executables in an
isolated environment and do not run them on a host system.
