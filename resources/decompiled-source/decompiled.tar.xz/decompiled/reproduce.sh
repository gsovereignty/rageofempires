#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT="$ROOT/decompiled"
EXTRACTED="$OUT/extracted"
PROJECTS="$OUT/ghidra-project"
GHIDRA_ROOT=${GHIDRA_ROOT:-/opt/homebrew/opt/ghidra/libexec}
JAVA_21_HOME=${JAVA_21_HOME:-/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home}
HEADLESS="$GHIDRA_ROOT/support/analyzeHeadless"

command -v innoextract >/dev/null
test -x "$HEADLESS"
test -x "$JAVA_21_HOME/bin/java"
mkdir -p "$EXTRACTED" "$PROJECTS"

innoextract \
  -d "$EXTRACTED" \
  -I "app/AoK HD.exe" \
  -I "app/steam_api.dll" \
  "$ROOT/setup.exe"

analyze() {
  project=$1
  input=$2
  output=$3

  env JAVA_HOME="$JAVA_21_HOME" "$HEADLESS" \
    "$PROJECTS" "$project" \
    -import "$input" \
    -scriptPath "$OUT" \
    -postScript ExportDecompiled.java "$output" \
    -overwrite
}

analyze AOEOriginal \
  "$EXTRACTED/app/AoK HD.exe" \
  "$OUT/AoK-HD-original.c"
analyze AOEPatched \
  "$ROOT/Crack/AoK HD.exe" \
  "$OUT/AoK-HD-patched.c"
analyze SteamOriginal \
  "$EXTRACTED/app/steam_api.dll" \
  "$OUT/steam-api-original.c"
analyze SteamPatched \
  "$ROOT/Crack/steam_api.dll" \
  "$OUT/steam-api-patched.c"

awk '
  BEGIN { OFS = "\t"; print "artifact", "address", "generated_name" }
  /^\\/\\* .* at [0-9A-Fa-f]+ \\*\\/$/ {
    line = $0
    sub(/^\\/\\* /, "", line)
    sub(/ \\*\\/$/, "", line)
    count = split(line, part, " at ")
    if (count == 2) {
      print FILENAME, part[2], part[1]
    }
  }
' "$OUT"/*.c > "$OUT/function-index.tsv"

{
  for binary in \
    "$ROOT/Crack/AoK HD.exe" \
    "$ROOT/Crack/steam_api.dll" \
    "$EXTRACTED/app/AoK HD.exe" \
    "$EXTRACTED/app/steam_api.dll"
  do
    printf '\n===== %s =====\n' "$binary"
    objdump -p "$binary"
  done
} > "$OUT/pe-metadata-and-imports.txt"

strings -a "$ROOT/Crack/AoK HD.exe" \
  > "$OUT/AoK-HD-patched.strings.txt"

echo "Generated:"
wc -l -c \
  "$OUT"/*.c \
  "$OUT/function-index.tsv" \
  "$OUT/pe-metadata-and-imports.txt" \
  "$OUT/AoK-HD-patched.strings.txt"
