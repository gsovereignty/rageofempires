# Binary provenance manifest

SHA-256 hashes and PE timestamps below identify the exact research inputs.
PE timestamps are compiler/linker metadata and may be inaccurate or altered.

| File | Bytes | SHA-256 | PE timestamp |
|---|---:|---|---|
| `setup.exe` | 458,739 | `db28b74cfcc12184b1c50436be1927a80877c0f99ed7f207695a9992295dece5` | 1992-06-19 23:22:17 |
| `setup-1.bin` | 1,439,178,295 | `409bef7ffeb957933161f2b7ec2d9819333af1d1d14d92e149ecff0bd55f092e` | n/a |
| `Crack/AoK HD.exe` | 4,444,160 | `e23272e21014fb281f71a21ef96a6437ab8b322f4978fd4998be835be219edcc` | 2013-04-03 20:48:17 |
| `Crack/steam_api.dll` | 288,772 | `e64ce9857f2816a600f2b179ec91f5cae270d55c75c4f088d6773ac27f2bf926` | 2013-04-04 16:37:30 |
| Extracted `AoK HD.exe` | 56,320 | `02ccff32765e19f4f75be5454c74e85bd78cc2fccea44ba21176371f715aa1fb` | 2013-04-01 21:54:15 |
| Extracted `steam_api.dll` | 103,920 | `8c073e0d2ca39d1e986bec348f988303357be5c495ccf6e0415802b86eae3534` | 2012-12-12 01:05:28 |

All executables are 32-bit little-endian Windows PE files targeting x86.

Primary game imports:

```text
d3d9.dll
DSOUND.dll
IMM32.dll
steam_api.dll
VERSION.dll
WINMM.dll
zlibwapi.dll
KERNEL32.dll
USER32.dll
GDI32.dll
COMDLG32.dll
ADVAPI32.dll
ole32.dll
```
